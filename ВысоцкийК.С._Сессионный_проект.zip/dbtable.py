class DbTable:
    dbconn = None

    def table_name(self):
        return self.dbconn.prefix + 'table'

    def columns(self):
        return {}

    def column_names(self):
        return sorted(self.columns().keys())

    def primary_key(self):
        return []

    def table_constraints(self):
        return []

    def insert_columns(self):
        return self.column_names()

    def execute(self, sql, params=None, commit=True):
        cur = self.dbconn.conn.cursor()
        try:
            cur.execute(sql, params)
            if commit:
                self.dbconn.conn.commit()
        except Exception:
            self.dbconn.conn.rollback()
            raise
        return cur

    def create(self):
        parts = [k + ' ' + ' '.join(v) for k, v in sorted(self.columns().items())]
        sql = 'CREATE TABLE ' + self.table_name() + '(' + ', '.join(parts + self.table_constraints()) + ')'
        self.execute(sql)

    def drop(self):
        self.execute('DROP TABLE IF EXISTS ' + self.table_name())

    def insert_one(self, vals, commit=True):
        cols = self.insert_columns()
        if isinstance(vals, dict):
            vals = tuple(vals[c] for c in cols)
        sql = 'INSERT INTO ' + self.table_name() + '(' + ', '.join(cols) + ') VALUES('
        sql += ', '.join(['%s'] * len(cols)) + ')'
        self.execute(sql, tuple(vals), commit=commit)

    def all(self):
        sql = 'SELECT * FROM ' + self.table_name()
        if self.primary_key():
            sql += ' ORDER BY ' + ', '.join(self.primary_key())
        return self.execute(sql).fetchall()

    def first(self):
        sql = 'SELECT * FROM ' + self.table_name()
        if self.primary_key():
            sql += ' ORDER BY ' + ', '.join(self.primary_key())
        sql += ' LIMIT 1'
        return self.execute(sql).fetchone()

    def find_by_position(self, num):
        sql = 'SELECT * FROM ' + self.table_name()
        if self.primary_key():
            sql += ' ORDER BY ' + ', '.join(self.primary_key())
        sql += ' LIMIT 1 OFFSET %s'
        return self.execute(sql, (num - 1,)).fetchone()

    def find_by_pk(self, key_values):
        where = ' AND '.join(k + ' = %s' for k in self.primary_key())
        sql = 'SELECT * FROM ' + self.table_name() + ' WHERE ' + where
        return self.execute(sql, tuple(key_values[k] for k in self.primary_key())).fetchone()

    def update_one(self, old_key, new_values, commit=True):
        set_cols = [c for c in self.column_names() if c in new_values]
        if not set_cols:
            return
        sets = ', '.join(c + ' = %s' for c in set_cols)
        where = ' AND '.join(k + ' = %s' for k in self.primary_key())
        sql = 'UPDATE ' + self.table_name() + ' SET ' + sets + ' WHERE ' + where
        params = tuple(new_values[c] for c in set_cols)
        params += tuple(old_key[k] for k in self.primary_key())
        self.execute(sql, params, commit=commit)

    def delete_one(self, key_values, commit=True):
        where = ' AND '.join(k + ' = %s' for k in self.primary_key())
        sql = 'DELETE FROM ' + self.table_name() + ' WHERE ' + where
        self.execute(sql, tuple(key_values[k] for k in self.primary_key()), commit=commit)

    def count_where(self, condition, params, table=None):
        sql = 'SELECT COUNT(*) FROM ' + (table or self.table_name()) + ' WHERE ' + condition
        return self.execute(sql, tuple(params)).fetchone()[0]

    def rows_where(self, condition, params, table=None, order_by=None):
        sql = 'SELECT * FROM ' + (table or self.table_name()) + ' WHERE ' + condition
        if order_by:
            sql += ' ORDER BY ' + order_by
        return self.execute(sql, tuple(params)).fetchall()
