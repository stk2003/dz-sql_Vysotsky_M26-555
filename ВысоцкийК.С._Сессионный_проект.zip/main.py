# Высоцкий Константин Сергеевич
# Вариант 19 (18 % 26 + 1 = 19)
# Условия задания варианта: таблицы водители и машины без связей с другими таблицами.
# Первая таблица — водители (добавление, изменение, удаление), вторая — машины
# (просмотр по ИНН водителя, добавление с этим ключом, удаление).
# Связь взята из ДЗ модуля 1: водитель закреплён за машиной.
# В интерфейсе не используются суррогатные ключи, все значения передаются параметрами запросов.
# Дополнительно реализованы постраничный просмотр и изменение машин (задание 7).

import re
import sys
from datetime import date, datetime

import psycopg2

sys.path.append('tables')

from project_config import ProjectConfig
from dbconnection import DbConnection
from dbtable import DbTable
from cars_table import CarsTable
from drivers_table import DriversTable


PAGE_SIZE = 5


CAR_SAMPLE = [
    {'car_plate': 'А123ВС77', 'brand': 'Hyundai Solaris', 'car_class': 'эконом',
     'color': 'белый', 'production_year': 2020},
    {'car_plate': 'В456ТМ97', 'brand': 'Kia Rio', 'car_class': 'эконом',
     'color': 'серый', 'production_year': 2019},
    {'car_plate': 'Е789КН99', 'brand': 'Toyota Camry', 'car_class': 'бизнес',
     'color': 'чёрный', 'production_year': 2021},
    {'car_plate': 'М321ОТ177', 'brand': 'Skoda Octavia', 'car_class': 'эконом',
     'color': 'серебристый', 'production_year': 2022},
    {'car_plate': 'Т654АХ197', 'brand': 'Mercedes-Benz E-Class', 'car_class': 'бизнес',
     'color': 'чёрный', 'production_year': 2018},
    {'car_plate': 'О111МК78', 'brand': 'Volkswagen Polo', 'car_class': 'эконом',
     'color': 'синий', 'production_year': 2017},
    {'car_plate': 'С222МВ02', 'brand': 'Renault Logan', 'car_class': 'эконом',
     'color': 'белый', 'production_year': 2016}
]

DRIVER_SAMPLE = [
    {'inn': '770000000001', 'surname': 'Иванов', 'first_name': 'Иван',
     'patronymic': 'Иванович', 'birth_date': date(1988, 4, 12),
     'passport_series': '4510', 'passport_number': '123456', 'car_plate': 'А123ВС77'},
    {'inn': '770000000002', 'surname': 'Петров', 'first_name': 'Пётр',
     'patronymic': 'Петрович', 'birth_date': date(1990, 7, 23),
     'passport_series': '4511', 'passport_number': '234567', 'car_plate': 'В456ТМ97'},
    {'inn': '770000000003', 'surname': 'Сидоров', 'first_name': 'Алексей',
     'patronymic': 'Сергеевич', 'birth_date': date(1985, 11, 5),
     'passport_series': '4512', 'passport_number': '345678', 'car_plate': 'Е789КН99'},
    {'inn': '770000000004', 'surname': 'Кузнецов', 'first_name': 'Дмитрий',
     'patronymic': 'Андреевич', 'birth_date': date(1992, 2, 14),
     'passport_series': '4513', 'passport_number': '456789', 'car_plate': 'М321ОТ177'},
    {'inn': '770000000005', 'surname': 'Смирнов', 'first_name': 'Михаил',
     'patronymic': 'Викторович', 'birth_date': date(1979, 9, 30),
     'passport_series': '4514', 'passport_number': '567890', 'car_plate': 'Т654АХ197'},
    {'inn': '780000000006', 'surname': 'Волков', 'first_name': 'Артём',
     'patronymic': 'Игоревич', 'birth_date': date(1995, 1, 18),
     'passport_series': '6315', 'passport_number': '678901', 'car_plate': 'О111МК78'}
]


class Main:

    config = ProjectConfig()
    connection = None

    def __init__(self):
        self.connection = DbConnection(self.config)
        DbTable.dbconn = self.connection

    @staticmethod
    def row_dict(table, row):
        return dict(zip(table.column_names(), row))

    @staticmethod
    def read(prompt):
        return input(prompt).strip()

    @staticmethod
    def handle_db_error(error):
        print('Ошибка базы данных: ' + str(error).split('\n')[0])

    @staticmethod
    def paginate(rows, page):
        total_pages = max(1, (len(rows) + PAGE_SIZE - 1) // PAGE_SIZE)
        page = max(1, min(page, total_pages))
        start = (page - 1) * PAGE_SIZE
        return rows[start:start + PAGE_SIZE], page, total_pages

    @classmethod
    def ask_value(cls, prompt, current=None, required=True, max_len=50, pattern=None):
        hint = ' (Enter — без изменений)' if current is not None else ''
        while True:
            value = cls.read(prompt + hint)
            if value == '0':
                return None
            if not value and current is not None:
                return current
            if not value:
                if required:
                    print('Поле обязательно для заполнения!')
                    continue
                return None
            if len(value) > max_len:
                print('Слишком длинное значение, не более ' + str(max_len) + ' символов!')
                continue
            if pattern and not re.fullmatch(pattern, value):
                print('Неверный формат значения!')
                continue
            return value

    @classmethod
    def ask_date(cls, prompt, current=None):
        hint = ' (Enter — без изменений)' if current is not None else ''
        while True:
            value = cls.read(prompt + hint)
            if value == '0':
                return None
            if not value and current is not None:
                return current
            try:
                result = datetime.strptime(value, '%d.%m.%Y').date()
            except ValueError:
                print('Введите дату в формате ДД.ММ.ГГГГ!')
                continue
            if result > date.today():
                print('Дата рождения не может быть в будущем!')
                continue
            return result

    @classmethod
    def ask_number(cls, prompt, minimum, maximum, current=None):
        hint = ' (Enter — без изменений)' if current is not None else ''
        while True:
            value = cls.read(prompt + hint)
            if value == '0':
                return None
            if not value and current is not None:
                return current
            if not value.isdigit() or not minimum <= int(value) <= maximum:
                print('Введите число от ' + str(minimum) + ' до ' + str(maximum) + '!')
                continue
            return int(value)

    @classmethod
    def ask_menu(cls, maximum):
        while True:
            value = cls.read('=> ')
            if value.isdigit() and (0 <= int(value) <= maximum or value == '9'):
                return value
            print('Выбрано неверное число! Повторите ввод!')

    @staticmethod
    def confirm(prompt):
        while True:
            value = Main.read(prompt + ' (д/н): ').lower()
            if value in ('д', 'да', 'y', 'yes'):
                return True
            if value in ('н', 'нет', 'n', 'no', ''):
                return False
            print('Ответьте "д" или "н"!')

    def db_init(self):
        CarsTable().create()
        DriversTable().create()
        print('Таблицы созданы заново!')

    def db_drop(self):
        DriversTable().drop()
        CarsTable().drop()

    def db_insert_somethings(self):
        for car in CAR_SAMPLE:
            CarsTable().insert_one(car)
        for driver in DRIVER_SAMPLE:
            DriversTable().insert_one(driver)

    @classmethod
    def ask_plate(cls, current=None):
        hint = ' (Enter — без изменений)' if current else ''
        while True:
            value = cls.read('Госномер (например А123ВС77, 0 - отмена)' + hint + ': ').upper()
            if value == '0':
                return None
            if not value and current:
                return current
            if not re.fullmatch(r'[АВЕКМНОРСТУХABEKMHOPCTYX][0-9]{3}[АВЕКМНОРСТУХABEKMHOPCTYX]{2}[0-9]{2,3}', value):
                print('Неверный формат госномера!')
                continue
            if len(value) > 12:
                print('Госномер слишком длинный!')
                continue
            return value

    def choose_car_plate(self, current=None):
        cars = CarsTable().all()
        if not cars:
            print('Сначала добавьте хотя бы одну машину!')
            return None
        print('Машины:')
        for number, row in enumerate(cars, 1):
            car = self.row_dict(CarsTable(), row)
            print(str(number) + '. ' + car['car_plate'] + ' | ' + car['brand']
                  + ' | ' + car['color'] + ' | ' + str(car['production_year']))
        hint = ' (Enter — без изменений)' if current else ''
        while True:
            value = self.read('Номер строки с машиной (0 - отмена)' + hint + ': ')
            if value == '0':
                return None
            if not value and current:
                return current
            if not value.isdigit() or not 1 <= int(value) <= len(cars):
                print('Некорректный номер строки!')
                continue
            return self.row_dict(CarsTable(), cars[int(value) - 1])['car_plate']

    def read_car_fields(self, current=None):
        current = current or {}
        old_plate = current.get('car_plate')
        while True:
            plate = self.ask_plate(old_plate)
            if plate is None:
                return None
            if plate != old_plate and CarsTable().find_by_pk({'car_plate': plate}):
                print('Машина с таким госномером уже есть!')
                continue
            break
        brand = self.ask_value('Марка и модель:', current.get('brand'), max_len=50,
                               pattern=r'[А-Яа-яЁёA-Za-z0-9\- ]+')
        if brand is None:
            return None
        print('Класс: 1 - бизнес, 2 - эконом')
        current_class = 1 if current.get('car_class') == 'бизнес' else 2
        car_class_choice = self.ask_number('Класс:', 1, 2,
                                           current_class if current else None)
        if car_class_choice is None:
            return None
        color = self.ask_value('Цвет:', current.get('color'), max_len=30,
                               pattern=r'[А-Яа-яЁёA-Za-z\- ]+')
        if color is None:
            return None
        year = self.ask_number('Год выпуска (1900-2026):', 1900, 2026,
                               current.get('production_year'))
        if year is None:
            return None
        return {'car_plate': plate, 'brand': brand,
                'car_class': 'бизнес' if car_class_choice == 1 else 'эконом',
                'color': color, 'production_year': year}


    def read_driver_fields(self, old=None):
        table = DriversTable()
        current = old or {}
        while True:
            inn = self.ask_value('ИНН (12 цифр):', current.get('inn'), max_len=12,
                                 pattern=r'[0-9]{12}')
            if inn is None:
                return None
            if inn != current.get('inn') and table.inn_exists(inn):
                print('Водитель с таким ИНН уже есть!')
                continue
            break
        surname = self.ask_value('Фамилия:', current.get('surname'),
                                 pattern=r'[А-Яа-яЁёA-Za-z\- ]+')
        if surname is None:
            return None
        first_name = self.ask_value('Имя:', current.get('first_name'),
                                    pattern=r'[А-Яа-яЁёA-Za-z\- ]+')
        if first_name is None:
            return None
        patronymic = self.ask_value('Отчество:', current.get('patronymic'),
                                    required=False, pattern=r'[А-Яа-яЁёA-Za-z\- ]+')
        if patronymic is None and current.get('patronymic') is not None:
            return None
        birth_date = self.ask_date('Дата рождения (ДД.ММ.ГГГГ):', current.get('birth_date'))
        if birth_date is None:
            return None
        while True:
            series = self.ask_value('Серия паспорта (4 цифры):', current.get('passport_series'),
                                    max_len=4, pattern=r'[0-9]{4}')
            if series is None:
                return None
            number = self.ask_value('Номер паспорта (6 цифр):', current.get('passport_number'),
                                    max_len=6, pattern=r'[0-9]{6}')
            if number is None:
                return None
            if table.passport_exists(series, number, current.get('inn')):
                print('Такой паспорт уже есть в базе!')
                continue
            break
        plate = self.choose_car_plate(current.get('car_plate'))
        if plate is None:
            return None
        return {'inn': inn, 'surname': surname, 'first_name': first_name,
                'patronymic': patronymic, 'birth_date': birth_date,
                'passport_series': series, 'passport_number': number,
                'car_plate': plate}

    def print_drivers(self, rows, page, total_pages):
        table = DriversTable()
        print('Список водителей:')
        print('№ | ИНН | Фамилия | Имя | Отчество | Дата рождения | Паспорт | Машина')
        for number, row in enumerate(rows, 1):
            driver = self.row_dict(table, row)
            print(str(number) + '. ' + driver['inn'] + ' | ' + driver['surname']
                  + ' | ' + driver['first_name'] + ' | ' + (driver['patronymic'] or '-')
                  + ' | ' + str(driver['birth_date']) + ' | ' + driver['passport_series']
                  + ' ' + driver['passport_number'] + ' | ' + driver['car_plate'])
        if not rows:
            print('Записей нет.')
        print('Страница ' + str(page) + ' из ' + str(total_pages))

    def choose_driver_row(self, rows):
        if not rows:
            print('Выбирать некого!')
            return None
        number = self.ask_number('Номер строки водителя (0 - отмена):', 1, len(rows))
        if number is None:
            return None
        return self.row_dict(DriversTable(), rows[number - 1])

    def add_driver(self):
        values = self.read_driver_fields()
        if values is None:
            return
        try:
            DriversTable().insert_one(values)
            print('Водитель добавлен!')
        except psycopg2.Error as error:
            self.handle_db_error(error)

    def edit_driver(self, old):
        values = self.read_driver_fields(old)
        if values is None:
            return
        try:
            DriversTable().update_one({'inn': old['inn']}, values)
            print('Данные водителя изменены!')
        except psycopg2.Error as error:
            self.handle_db_error(error)

    def delete_driver(self, old):
        print('Удалить водителя ' + old['surname'] + ' ' + old['first_name'] + '?')
        if not self.confirm('Удаление:'):
            return
        try:
            DriversTable().delete_one({'inn': old['inn']})
            print('Водитель удалён!')
        except psycopg2.Error as error:
            self.handle_db_error(error)

    def show_drivers(self):
        page = 1
        while True:
            page_rows, page, total_pages = self.paginate(DriversTable().all(), page)
            self.print_drivers(page_rows, page, total_pages)
            print('Операции: 1 - добавить; 2 - изменить; 3 - удалить; '
                  '4 - следующая страница; 5 - предыдущая страница; 0 - главное меню; 9 - выход')
            choice = self.ask_menu(5)
            if choice == '0' or choice == '9':
                return choice
            if choice == '1':
                self.add_driver()
            elif choice == '2':
                driver = self.choose_driver_row(page_rows)
                if driver:
                    self.edit_driver(driver)
            elif choice == '3':
                driver = self.choose_driver_row(page_rows)
                if driver:
                    self.delete_driver(driver)
            elif choice == '4':
                page = min(page + 1, total_pages)
            elif choice == '5':
                page = max(page - 1, 1)

    def print_cars(self, rows, page, total_pages):
        table = CarsTable()
        print('Машины водителя:')
        print('№ | Госномер | Марка | Класс | Цвет | Год')
        for number, row in enumerate(rows, 1):
            car = self.row_dict(table, row)
            print(str(number) + '. ' + car['car_plate'] + ' | ' + car['brand']
                  + ' | ' + car['car_class'] + ' | ' + car['color']
                  + ' | ' + str(car['production_year']))
        if not rows:
            print('У этого водителя машин нет.')
        print('Страница ' + str(page) + ' из ' + str(total_pages))

    def ask_driver_inn(self):
        while True:
            inn = self.read('ИНН водителя (12 цифр, 0 - отмена): ')
            if inn == '0':
                return None
            if not re.fullmatch(r'[0-9]{12}', inn):
                print('ИНН должен содержать 12 цифр!')
                continue
            if not DriversTable().inn_exists(inn):
                print('Водитель с таким ИНН не найден!')
                continue
            return inn

    def add_car_for_driver(self, inn):
        driver = self.row_dict(DriversTable(), DriversTable().find_by_pk({'inn': inn}))
        values = self.read_car_fields()
        if values is None:
            return
        plate = values['car_plate']
        if driver['car_plate'] == plate:
            print('У водителя уже закреплена эта машина!')
            return
        if driver['car_plate']:
            print('Сейчас у водителя машина ' + driver['car_plate'])
            if not self.confirm('Заменить её на новую?'):
                return
        try:
            CarsTable().insert_one(values, commit=False)
            DriversTable().update_one({'inn': inn}, {'car_plate': plate}, commit=False)
            self.connection.conn.commit()
            print('Машина добавлена и закреплена за водителем!')
        except psycopg2.Error as error:
            self.connection.conn.rollback()
            self.handle_db_error(error)

    def edit_car(self, car):
        values = self.read_car_fields(car)
        if values is None:
            return
        try:
            CarsTable().update_one({'car_plate': car['car_plate']}, values)
            print('Данные машины изменены!')
        except psycopg2.Error as error:
            self.handle_db_error(error)

    def delete_car(self, car, inn):
        table = CarsTable()
        drivers = table.drivers_for_plate(car['car_plate'])
        if drivers:
            print('Машина закреплена за водителями:')
            for driver in drivers:
                item = self.row_dict(DriversTable(), driver)
                print(item['inn'] + ' | ' + item['surname'] + ' ' + item['first_name'])
            if not self.confirm('Удалить машину вместе с этими водителями?'):
                print('Удаление отменено. Сначала переназначьте водителей другой машине.')
                return
        try:
            for driver in drivers:
                item = self.row_dict(DriversTable(), driver)
                DriversTable().delete_one({'inn': item['inn']}, commit=False)
            table.delete_one({'car_plate': car['car_plate']}, commit=False)
            self.connection.conn.commit()
            print('Машина удалена!')
        except psycopg2.Error as error:
            self.connection.conn.rollback()
            self.handle_db_error(error)

    def show_cars(self):
        inn = None
        page = 1
        while True:
            if inn is None:
                inn = self.ask_driver_inn()
                if inn is None:
                    return '0'
                page = 1
            driver_row = DriversTable().find_by_pk({'inn': inn})
            if driver_row is None:
                print('Выбранный водитель больше не существует, укажите другого!')
                inn = None
                continue
            driver = self.row_dict(DriversTable(), driver_row)
            print('Выбран водитель: ' + driver['surname'] + ' ' + driver['first_name']
                  + ' ' + (driver['patronymic'] or '') + ', ИНН ' + inn)
            page_rows, page, total_pages = self.paginate(CarsTable().all_by_driver_inn(inn), page)
            self.print_cars(page_rows, page, total_pages)
            print('Операции: 1 - добавить машину; 2 - удалить машину; 3 - изменить машину; '
                  '4 - следующая страница; 5 - предыдущая страница; '
                  '6 - выбрать другого водителя; 0 - главное меню; 9 - выход')
            choice = self.ask_menu(6)
            if choice == '0' or choice == '9':
                return choice
            if choice == '1':
                self.add_car_for_driver(inn)
            elif choice == '2':
                if not page_rows:
                    print('Удалять нечего!')
                    continue
                number = self.ask_number('Номер строки машины (0 - отмена):', 1, len(page_rows))
                if number:
                    self.delete_car(self.row_dict(CarsTable(), page_rows[number - 1]), inn)
            elif choice == '3':
                if not page_rows:
                    print('Изменять нечего!')
                    continue
                number = self.ask_number('Номер строки машины (0 - отмена):', 1, len(page_rows))
                if number:
                    self.edit_car(self.row_dict(CarsTable(), page_rows[number - 1]))
            elif choice == '4':
                page = min(page + 1, total_pages)
            elif choice == '5':
                page = max(page - 1, 1)
            elif choice == '6':
                inn = None

    def show_main_menu(self):
        print('Добро пожаловать!')
        print('Основное меню:')
        print('    1 - водители (просмотр, добавление, изменение, удаление);')
        print('    2 - машины (просмотр по ИНН водителя, добавление, удаление);')
        print('    3 - сброс и инициализация таблиц;')
        print('    9 - выход.')

    def after_main_menu(self, choice):
        if choice == '3':
            try:
                self.db_drop()
                self.db_init()
                self.db_insert_somethings()
                print('Таблицы созданы и заполнены!')
            except psycopg2.Error as error:
                self.connection.conn.rollback()
                self.handle_db_error(error)
            return '0'
        if choice not in ('1', '2', '9'):
            print('Выбрано неверное число! Повторите ввод!')
            return '0'
        return choice

    def main_cycle(self):
        current_menu = '0'
        while current_menu != '9':
            try:
                if current_menu == '0':
                    self.show_main_menu()
                    current_menu = self.after_main_menu(self.ask_menu(3))
                elif current_menu == '1':
                    current_menu = self.show_drivers()
                elif current_menu == '2':
                    current_menu = self.show_cars()
            except psycopg2.Error as error:
                self.connection.conn.rollback()
                self.handle_db_error(error)
                current_menu = '0'
            except Exception as error:
                print('Непредвиденная ошибка: ' + str(error))
                current_menu = '0'
        print('До свидания!')

    def test(self):
        print('Соединение с БД: ' + ('OK' if DbTable.dbconn.test() else 'Ошибка'))


if __name__ == '__main__':
    try:
        app = Main()
        app.main_cycle()
    except psycopg2.Error as error:
        print('Не удалось подключиться к базе данных. Проверьте config.yaml.')
        print('Подробности: ' + str(error).split('\n')[0])
    except Exception as error:
        print('Ошибка запуска: ' + str(error))
