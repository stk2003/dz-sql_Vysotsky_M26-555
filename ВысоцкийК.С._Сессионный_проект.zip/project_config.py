import os

import yaml


class ProjectConfig:
    def __init__(self):
        with open('config.yaml', encoding='utf-8') as f:
            config = yaml.safe_load(f)
        self.dbname = os.getenv('DB_NAME', config['dbname'])
        self.user = os.getenv('DB_USER', config['user'])
        self.password = os.getenv('DB_PASSWORD', config['password'])
        self.host = os.getenv('DB_HOST', config['host'])
        self.dbtableprefix = os.getenv('DB_TABLE_PREFIX', config['dbtableprefix'])
