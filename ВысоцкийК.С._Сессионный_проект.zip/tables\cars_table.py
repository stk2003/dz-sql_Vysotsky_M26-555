from dbtable import *


class CarsTable(DbTable):
    def table_name(self):
        return self.dbconn.prefix + 'cars'

    def columns(self):
        return {
            'car_plate': ['varchar(12)', 'PRIMARY KEY',
                          "CHECK (car_plate ~ '^[АВЕКМНОРСТУХABEKMHOPCTYX][0-9]{3}[АВЕКМНОРСТУХABEKMHOPCTYX]{2}[0-9]{2,3}$')"],
            'brand': ['varchar(50)', 'NOT NULL'],
            'car_class': ['varchar(10)', 'NOT NULL',
                          "CHECK (car_class IN ('бизнес', 'эконом'))"],
            'color': ['varchar(30)', 'NOT NULL'],
            'production_year': ['integer', 'NOT NULL',
                                'CHECK (production_year BETWEEN 1900 AND 2026)']
        }

    def primary_key(self):
        return ['car_plate']

    def all_by_driver_inn(self, inn):
        sql = 'SELECT c.* FROM ' + self.table_name() + ' c'
        sql += ' JOIN ' + self.dbconn.prefix + 'drivers d ON d.car_plate = c.car_plate'
        sql += ' WHERE d.inn = %s ORDER BY c.car_plate'
        return self.execute(sql, (inn,)).fetchall()

    def free_cars(self):
        sql = 'SELECT c.* FROM ' + self.table_name() + ' c'
        sql += ' LEFT JOIN ' + self.dbconn.prefix + 'drivers d ON d.car_plate = c.car_plate'
        sql += ' WHERE d.inn IS NULL ORDER BY c.car_plate'
        return self.execute(sql).fetchall()

    def drivers_for_plate(self, plate):
        return self.rows_where('car_plate = %s', (plate,),
                               table=self.dbconn.prefix + 'drivers', order_by='inn')
