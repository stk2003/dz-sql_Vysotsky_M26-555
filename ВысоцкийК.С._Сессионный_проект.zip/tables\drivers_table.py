from dbtable import *


class DriversTable(DbTable):
    def table_name(self):
        return self.dbconn.prefix + 'drivers'

    def columns(self):
        return {
            'inn': ['char(12)', 'PRIMARY KEY', "CHECK (inn ~ '^[0-9]{12}$')"],
            'surname': ['varchar(50)', 'NOT NULL'],
            'first_name': ['varchar(50)', 'NOT NULL'],
            'patronymic': ['varchar(50)'],
            'birth_date': ['date', 'NOT NULL'],
            'passport_series': ['char(4)', 'NOT NULL', "CHECK (passport_series ~ '^[0-9]{4}$')"],
            'passport_number': ['char(6)', 'NOT NULL', "CHECK (passport_number ~ '^[0-9]{6}$')"],
            'car_plate': ['varchar(12)', 'NOT NULL',
                          'REFERENCES ' + self.dbconn.prefix + 'cars(car_plate) ON UPDATE CASCADE ON DELETE RESTRICT']
        }

    def primary_key(self):
        return ['inn']

    def table_constraints(self):
        return ['CONSTRAINT uq_driver_passport UNIQUE (passport_series, passport_number)']

    def all_by_car_plate(self, plate):
        return self.rows_where('car_plate = %s', (plate,), order_by='inn')

    def inn_exists(self, inn):
        return self.count_where('inn = %s', (inn,)) > 0

    def passport_exists(self, series, number, exclude_inn=None):
        if exclude_inn:
            return self.count_where('passport_series = %s AND passport_number = %s AND inn <> %s',
                                    (series, number, exclude_inn)) > 0
        return self.count_where('passport_series = %s AND passport_number = %s',
                                (series, number)) > 0
